SLASH_HSDEMO1 = '/hsdemo'; -- 3.
function SlashCmdList.HSDEMO(msg, editbox) -- 4.
	HSDemo:Show()
end